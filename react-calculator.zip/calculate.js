import React from "react";
import './App.css';
import nerdamer from "nerdamer";

const Calculate =()=>{
    const numb = localStorage.getItem("enterednumber");
    console.log(numb);
    var result = nerdamer(numb).evaluate();
    var decimal=result.toString();
    //var ans = Number(decimal).toFixed(2); or eval or use split
    var ans= eval(decimal);
    console.log(ans);
     
       return(
        <div className="scrn">
          <span type="text" className="scren" readOnly>{ans}</span>
        </div>    
        
    )
};
export default Calculate;