import React, { useState } from "react";
import "./Calculator.css";
import Calculate from "./Calculate";

const Calculator = () => {
  var arr = [];
  const [edi, setEdit] = useState(arr);
  const [enable, setEnable] = useState(false);
  const addQuizHandler = (Data) => {
    setEdit((prevdata) => {
      return [...prevdata, Data];
    });
  };
  const saveFormDataHandler = (data) => {
    const Data = {
      ...data,
    };
    addQuizHandler(Data);

  };
  var click = (e) => {
    const data = {
      clicked: e.target.innerText,
    };
    saveFormDataHandler(data);
    setEnable(false);
  }
  var equal =(e)=>{
    setEnable(true);
  }
  var clear =()=>{
    setEnable(false);
    const newarr= [];    
    setEdit(newarr);   
  }
  
  const delt = () => {
    setEnable(false);
    edi.pop();
    console.log(edi);
    setEdit(edi);
  }
  
  var num = 0;

  return (
    <div>
      <div className="wrapper">
      <div className="scn">
          {enable===false && <span type="text" className="screen" readOnly> {edi.map((lis) => {
            num = num + lis.clicked || "0";
            localStorage.setItem("enterednumber", num);
            return  <span> {lis.clicked}</span>
            
          })}</span> }
        </div>   
        <div className="scn">
        {enable===true && <span type="text" className="screen" readOnly><Calculate/> </span> }
        </div>   

        <div className="buttonBox">
          <div className="button-row">
            <button onClick={clear} label={'Clear'}>Clr</button>
            <button onClick={delt} label={'Delete'}>Del</button>
            <button onClick={click} label={'%'}>%</button>
            <button onClick={click} label={'/'}>/</button>
          </div>
          <div className="button-row">
            <button onClick={click} label={'7'}>7</button>
            <button onClick={click} label={'8'}>8</button>
            <button onClick={click} label={'9'}>9</button>
            <button onClick={click} label={'*'}>*</button>
          </div>
          <div className="button-row">
            <button onClick={click} label={'4'}>4</button>
            <button onClick={click} label={'5'}>5</button>
            <button onClick={click} label={'6'}>6</button>
            <button onClick={click} label={'-'}>-</button>
          </div>
          <div className="button-row">
            <button onClick={click} label={'1'}>1</button>
            <button onClick={click} label={'2'}>2</button>
            <button onClick={click} label={'3'}>3</button>
            <button onClick={click} label={'+'}>+</button>
          </div>
          <div className="button-row">
            <button onClick={click} label={'0'}>0</button>
            <button onClick={click} label={'.'}>.</button>
            <button className="equals" onClick={equal} label={'='}>=</button>
          </div>
        </div>
      </div>
    </div>
  );

}

export default Calculator;